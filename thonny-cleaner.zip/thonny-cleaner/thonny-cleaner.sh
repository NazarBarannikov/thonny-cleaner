#!/bin/bash
# patch-thonny.sh

# Получаем абсолютный путь к директории, где лежит Thonny
THONNY_PATH=$(python3 -c "import thonny; print(thonny.__path__[0])")

# Получаем абсолютный путь к директории, где лежит этот скрипт
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

#Заменить workbench.py на свой заранее подготовленный файл
cp -f "$DIR/workbench.py" "$THONNY_PATH/workbench.py"

# Удалить картинки
rm -f "$THONNY_PATH/res/Ukraine.png"
rm -f "$THONNY_PATH/res/Ukraine_2x.png"
